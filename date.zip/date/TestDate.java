public class TestDate {
 
    public static void main(String[] args) {

        //Using a random date for testing
        Date saydate = new Date(7, 21, 2005);
        //Say the date after a blank line to help with visual clarity
        System.out.println("");
        System.out.println("The date is: " + saydate.toString());


    }
}
